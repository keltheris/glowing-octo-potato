<?php
namespace mlBotPrevention\EventObservers\Logger;

class Logger extends \Monolog\Logger
{
}
