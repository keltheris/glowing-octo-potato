<?php

namespace mlBotPrevention\EventObservers\Observer;

use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
#use mlBotPrevention\EventObservers\Logger\Logger

class Data implements ObserverInterface
{

	public function execute(Observer $observer)
	{
		$file = fopen("var/log/timestamps.txt", "a");
		fwrite($file, strval(time()));
		fwrite($file, "\n");
		fclose($file);
	}
}
