<?php

namespace mlBotPrevention\EventObservers\Observer;

use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;

# Ordermanagement event observer gets invoked when
# the customer finally places their order at the end
# of the checkout process. I will grab out relevant
# information and send it to the ML engine for
# adjudication. If the adjudication comes back stating
# its suspected to be a bot then the order is cancelled.
# otherwise the order is left as is.
class OrderManagement implements ObserverInterface
{
	protected $_curl;

	public function __construct(\Magento\Framework\HTTP\Client\Curl $curl) 
	{
		$this->_curl = $curl;
	}
	public function execute(Observer $observer)
	{
		$file = fopen("var/log/timestamps2.txt", "a");

		# magento items from place order event
		$ordered = time();
		$order = $observer->getEvent()->getOrder();
		$items = $order->getItems();

		# Get time stamp from when item was added to cart
		$file2 = escapeshellarg("/var/www/html/magento2/var/log/timestamps.txt");
		$line = `tail -n 1 $file2`;

		# get some of the needed arbitration values
		$ttc = strval(intval($ordered) - intval($line));
		$postcode = $order->getShippingAddress()->getPostcode();
		$isguest = $order->getCustomerIsGuest();
		$ip = $order->getRemoteIp();

		# parse out items ordered
		foreach ($items as $item) {
			$sku = $item->getSku();
			$qty = $item->getQtyOrdered();
			$price = $item->getPrice();
		}	

		# check if guest account and format
		# (Theres no explicit account age (not age of customer)
		# field to retrieve so I'm just spoofing 365 days.
		# I could try to possible get customer object and then
		# call the getCreatedAt() which MIGHT be the account age
		if ($isguest == 1) {
			$age = 0;
			$isguest="guest";
		} else {
			$age = 365;
			$isguest="account";
		}

		# Since I'm keeping it local I need to spoof an external IP
		# for my model engine. Internal IPs crash the model engine
		# because I convert an IP to an estimated location and
		# you cant estimate location off an internal IP
		$ip = '69.134.12.34';

		# IP address of my ML engine
		$url='http://192.168.50.209:8080';

		# curl to make the post request to the ML Engine front end
		$data = array(
			'stock_code' => $sku,
			'ttc' => $ttc,
			'quantity' => $qty,
			'unit_price' => $price,
			'account_type' => $isguest,
			'account_age' => $age,
			'ip' => $ip,
			'shipping_zip' => $postcode
		);
		$data_string=json_encode($data);

		$this->_curl->addHeader("Content-Type", "application/json");
		$this->_curl->addHeader("Content-Length", strlen($data_string));
		$this->_curl->post($url, $data_string);
		$response = $this->_curl->getBody();
		$result = json_decode($response)->result;

		# Check the result from the ML Engine
		# false: not a bot
		# true: bot, cancel order
		if($result == "false") {
			fwrite($file, "Valid order");
			fwrite($file, "\n");
		} else {
			$order=$order->cancel();
			if($order->isCanceled()) {
				fwrite($file, "Bot suspected, order cancelled");
				fwrite($file, "\n");
			}
		}

		fclose($file);
	}
}
