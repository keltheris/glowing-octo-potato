import time

from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import Select


class CheckOutBot:
    def __init__(self):
        self.driver = webdriver.Chrome(executable_path='/home/jeremy/cs6727_prac/bot_demo/chromedriver')
        self.driver.get("http://192.168.50.93/magento2/")

    def set_quantity(self, amount):
        quantity = self.driver.find_element(By.ID, "qty")
        quantity.clear()
        quantity.send_keys(amount)

    def add_product_to_cart(self, link, amount):
        self.driver.get(link)
        time.sleep(2)
        self.set_quantity(amount)
        add_to_cart_button = self.driver.find_element("id", "product-addtocart-button")
        add_to_cart_button.click()

    def checkout(self):
        self.driver.get("http://192.168.50.93/magento2/checkout/")
        time.sleep(2)
        email_address = self.driver.find_element("id", "customer-email")
        email_address.clear()
        email_address.send_keys("bot@bot.com")

        first_name = self.driver.find_element(By.XPATH,
                "//input[@class='input-text' and @name='firstname']")
        first_name.clear()
        first_name.send_keys("bot")

        last_name = self.driver.find_element(By.XPATH,
                "//input[@class='input-text' and @name='lastname']")
        last_name.clear()
        last_name.send_keys("bot")

        street_address = self.driver.find_element(By.XPATH,
                "//input[@class='input-text' and @name='street[0]']")
        street_address.clear()
        street_address.send_keys("123 bot st")

        city = self.driver.find_element(By.XPATH,
                "//input[@class='input-text' and @name='city']")
        city.clear()
        city.send_keys("botville")

        state = self.driver.find_element(By.XPATH,
                "//select[@class='select' and @name='region_id']")
        select = Select(state)
        select.select_by_visible_text("California")

        postal = self.driver.find_element(By.XPATH,
                "//input[@class='input-text' and @name='postcode']")
        postal.clear()
        postal.send_keys("94016")

        phone_number = self.driver.find_element(By.XPATH,
                "//input[@class='input-text' and @name='telephone']")
        phone_number.clear()
        phone_number.send_keys("1234567890")

        checkout_button = self.driver.find_element(By.XPATH,
                "//button[@type='submit' and @class='button action continue primary']")
        checkout_button.click()

        time.sleep(2)

        place_order_button = self.driver.find_element(By.XPATH,
                "//button[@type='submit' and @class='action primary checkout']")
        place_order_button.click()


if __name__ == "__main__":
    # Scalping item
    checkout_bot = CheckOutBot()
    checkout_bot.add_product_to_cart(
            "http://192.168.50.93/magento2/xbox-series-x.html",
            "1"
    )
    checkout_bot.checkout()
    time.sleep(5)

    # Non-scalping item
    checkout_bot = CheckOutBot()
    checkout_bot.add_product_to_cart(
            "http://192.168.50.93/magento2/paper-clips.html",
            "9999"
    )
    checkout_bot.checkout()
    time.sleep(5)

    # Scalping item slow checkout, lots of items
    checkout_bot = CheckOutBot()
    checkout_bot.add_product_to_cart(
            "http://192.168.50.93/magento2/xbox-series-x.html",
            "10"
    )
    time.sleep(35)
    checkout_bot.checkout()

