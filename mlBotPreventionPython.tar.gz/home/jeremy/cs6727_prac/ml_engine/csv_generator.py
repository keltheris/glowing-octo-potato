from random import randrange

cap = 75000
tenth = cap - 7500
def bin_ttc(ttc):
    if ttc < 5:
        ttc_bin = "extremely fast"
    elif ttc < 15:
        ttc_bin = "really fast"
    elif ttc < 30:
        ttc_bin = "fast"
    elif ttc < 75:
        ttc_bin = "normal"
    else:
        ttc_bin = "slow"

    return ttc_bin

def bin_quantity(quantity):
    if quantity < 2:
        quantity_bin = "single"
    elif quantity < 3:
        quantity_bin = "double"
    elif quantity < 6:
        quantity_bin = "multiple"
    else:
        quantity_bin = "a lot"

    return quantity_bin

def bin_total(total):
    if total < 400:
        total_bin = "low"
    elif total < 500:
        total_bin = "moderate"
    elif total < 1000:
        total_bin = "high"
    else:
        total_bin = "extremely high"

    return total_bin

def bin_account_age(account_age):
    if account_age == 0:
        account_age_bin = "guest or new"
    elif account_age < 365:
        account_age_bin = "under year account"
    elif account_age < 1095:
        account_age_bin = "under 3 year account"
    else:
        account_age_bin = "established account"

    return account_age_bin

def bin_distance(distance):
    if distance < 25:
        distance_bin = "local order"
    elif distance < 60:
        distance_bin = "commuter order"
    elif distance < 500:
        distance_bin = "vacationer order"
    else:
        distance_bin = "far order"

    return distance_bin


csv_header="TTC,Quantity,Total,AccountAge,Distance,flag,y"

ttc = bin_ttc(0)
quantity = bin_quantity(1)
total = bin_total(15)
account_age = bin_account_age(0)
distance = bin_distance(0)

csv_file = open("./data/transaction_hist_1.csv", "a")
csv_file.write(csv_header+'\n')

for i in range(cap):

    # do bad data
    if randrange(100) < 15:
        ttc= bin_ttc(randrange(1, 20))
        distance = bin_distance(randrange(0,6000))
        quantity_unbinned = randrange(0, 11)
        quantity = bin_quantity(quantity_unbinned)
        total = bin_total(quantity_unbinned * 400)
        y = 1
    # do good data
    else:
        # generate "real". Testing with sample size of 62 shows
        # average ttc  of 39 with a stdev of 11.5
        # however I don't believe the lowend of human checkout time could be as
        # fast as 5s so I took the lowest checkout time record (29s) and made
        # that the lowest bound.
        randNum = randrange(100) + 1
        if randNum < 16:
            ttc= bin_ttc(randrange(28, 30))
        elif randNum < 50:
            ttc= bin_ttc(randrange(30, 39))
        elif randNum < 85:
            ttc= bin_ttc(randrange(39, 50))
        elif randNum < 99:
            ttc= bin_ttc(randrange(50, 62))
        else:
            ttc= bin_ttc(randrange(62, 158))

        distance = bin_distance(randrange(0,1000))
        quantity_unbinned = randrange(0, 3)
        quantity = bin_quantity(quantity_unbinned)
        total = bin_total(quantity_unbinned * 400)
        y = 0

    account_type = randrange(0, 2)
    if account_type == 0:
        account_age = bin_account_age(0)
    else:
        account_age = bin_account_age(randrange(0, 1865))


    if i < tenth:
        flag = "train"
    else:
        flag = "test"
    csv_file.write(str(ttc)+','+str(quantity)+','+str(total) +','
           +str(account_age)+','+str(distance)+','+flag+','+str(y)+'\n')

csv_file.close()
