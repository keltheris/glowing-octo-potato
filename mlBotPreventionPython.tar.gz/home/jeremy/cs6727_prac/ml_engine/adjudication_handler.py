import socketserver
import requests
import json
import cgi
import pgeocode

from adjudication_engine import *
from http.server import BaseHTTPRequestHandler
from geopy.distance import geodesic

class MyHandler(BaseHTTPRequestHandler):

    def do_GET(self):
        self.send_response(404)
        self.end_headers()

    def do_POST(self):
        try:
            # get post request data
            ctype, pdict = cgi.parse_header(self.headers['content-type'])

            if ctype != 'application/json':
                self.send_response(400)
                self.end_headers()
                return

            length = int(self.headers['content-length'])
            message = json.loads(self.rfile.read(length))

            # Delete me
            print(message)
            # The actual adjudication request data to operate off of
            stock_code = message['stock_code']
            ttc = message['ttc']
            quantity = message['quantity']
            unit_price = message['unit_price']
            account_type = message['account_type']
            account_age = message['account_age']
            ip = message['ip']
            shipping_zip = message['shipping_zip']

            # Check if it's a scalper item, if not dont do ML check
            if stock_code_scalped(int(stock_code)):

                # Take the IP order was place from and get estimated location
                # Also convert shipping address to lat and long
                estimated_location_from_ip = get_location(ip)
                nomi = pgeocode.Nominatim('us')
                estimated_location_from_zip = nomi.query_postal_code(shipping_zip)

                ordered_from = (estimated_location_from_ip['lat'],
                                estimated_location_from_ip['long'])
                shipping_to =  (estimated_location_from_zip['latitude'],
                                estimated_location_from_zip['longitude'])


                # Take shipping zip and estimated location and get distance between
                # the two in miles. Straight distance between 2 points, not
                # "real" distance meaning via roads, etc. aka "as the crow flies"
                distance = geodesic(ordered_from, shipping_to).mi

                if verbose:
                    print(estimated_location_from_ip['postal'] + ': ', end='')
                    print(ordered_from)
                    print(shipping_zip + ': ', end='')
                    print(shipping_to)
                    print(distance)

                if account_type == "guest":
                    account_age_var = 0
                else:
                    account_age_var = account_age

                # Fit data to model
                binned_data = bin_data(ttc, quantity, unit_price, account_age_var, distance)

                # Request adjudication of data from ML engine
                result=parse_adjudication_request(binned_data)
            else:
                result = {'result': 'false'}

            # Boilerplate responding back to server with results
            print("Is bot: ", end='')
            print(result['result'])
            self.send_response(200)
            self.send_header('Content-Type', 'application/json')
            self.end_headers()
            self.wfile.write(json.dumps(result).encode())
        except:
            print("Server crashed")
            httpd.server_close()

# Makes the call to the ML engine to have the data classified as either
# bot or not a bot
# In:
#   Formatted python dict that can be turned into a panda dataframe
# Out:
#    A dictionary that represents the result of the adjudication request.
#    False means it is not believed to be a bot.
#    True means it is believed to be a bot.
# See:
#    bin_data() for dict format
def parse_adjudication_request(binned_data):
    result = adjudicate(binned_data)
    if result:
        return {'result': 'true'}
    else:
        return {'result': 'false'}

# Returns a boolean representing if the product should be sent to the ML engine
# for adjudication
# In:
#    Stock code of item being purchased
# Out:
#    Boolean, true means do send to ML Engine, False means dont
def stock_code_scalped(stock_code):
    if stock_code < 4:
        return True
    else:
        return False

# Takes data from Magento2 and turns it into a specific structure that can
# be turned into a panda DataFrame. This format is required by the ML Engine.
# This function takes the data, bins it into the model values, then returns
# the structure that can be used in the ML Engine.
# In:
#    ttc - time to checkout
#    quantity - the amount of product being purchased
#    unit_price - the price of the product
#    account_age - age of the account, 0 if guest
#    distance - distance in miles between shipping zip and estimated location
#               of the IP the order was placed from
# Out:
#     A python list of a dict that can be converted into a panda DataFrame for
#     the ML Engine. Each bin needs to be represented in the DataFrame. A '0'
#     value means false whereas a '1' value means true. For example
#     TTC_extremely_fast = 0 means the ttc was not extremely fast (under 5
#     seconds) whereas a TTC_normal = 1 means the ttc took 30-74 seconds.
#
#     practical example: TTC = 18 seconds, quantity = 1, total = 700,
#     account age = 0 and distance = 45 would produce the following:
#     Note: alphabetization after column tag i.e. TTC_<alphabetized>
#        'TTC_extremely fast': 0,
#        'TTC_fast': 1,
#        'TTC_normal': 0,
#        'TTC_really fast': 0,
#        'TTC_slow': 0,
#        'Quantity_a lot': 0,
#        'Quantity_double': 0,
#        'Quantity_multiple': 0,
#        'Quantity_single': 1,
#        'Total_extremely high': 0,
#        'Total_high': 1,
#        'Total_low': 0,
#        'Total_moderate': 0,
#        'AccountAge_established account': 0,
#        'AccountAge_guest or new': 1,
#        'AccountAge_under 3 year account': 0,
#        'AccountAge_under year account': 0,
#        'Distance_commuter order': 1,
#        'Distance_far order': 0,
#        'Distance_local order': 0,
#        'Distance_vacationer order': 0
def bin_data(ttc, quantity, unit_price, account_age, distance):
    # Set all dict values to '0', only 5 will be '1'
    TTC_extremely_fast = 0
    TTC_fast = 0
    TTC_normal = 0
    TTC_really_fast = 0
    TTC_slow = 0
    Quantity_a_lot = 0
    Quantity_double = 0
    Quantity_multiple = 0
    Quantity_single = 0
    Total_extremely_high = 0
    Total_high = 0
    Total_low = 0
    Total_moderate = 0
    AccountAge_established_account = 0
    AccountAge_guest_or_new = 0
    AccountAge_under_3_year_account = 0
    AccountAge_under_year_account = 0
    Distance_commuter_order = 0
    Distance_far_order = 0
    Distance_local_order = 0
    Distance_vacationer_order = 0

    # Cast to int
    ttc_int = int(ttc)
    quantity_int = int(quantity)
    unit_price_int = int(unit_price)
    account_age_int = int(account_age)
    distance_int = int(distance)

    # convert quantity and unit price to total cost
    total = quantity_int * unit_price_int

    # Bin data
    # This is the "modelling"
    if ttc_int < 5:
        TTC_extremely_fast = 1
    elif ttc_int < 15:
        TTC_really_fast = 1
    elif ttc_int < 30:
        TTC_fast = 1
    elif ttc_int < 75:
        TTC_normal = 1
    else:
        TTC_slow = 1

    if quantity_int < 2:
        Quantity_single = 1
    elif quantity_int < 3:
        Quantity_double = 1
    elif quantity_int < 6:
        Quantity_multiple = 1
    else:
        Quantity_a_lot = 1

    if total < 400:
        Total_low = 1
    elif total < 500:
        Total_moderate = 1
    elif total < 1000:
        Total_high = 1
    else:
        Total_extremely_high = 1

    if account_age_int == 0:
        AccountAge_guest_or_new = 1
    elif account_age_int < 365:
        AccountAge_under_year_account = 1
    elif account_age_int < 1095:
        AccountAge_under_3_year_account = 1
    else:
        AccountAge_established_account = 1

    if distance_int < 25:
        Distance_local_order = 1
    elif distance_int < 60:
        Distance_commuter_order = 1
    elif distance_int < 500:
        Distance_vacationer_order = 1
    else:
        Distance_far_order = 1

    # Create the data structure needed by the ML Engine
    binned_data = [{
        'TTC_extremely fast': TTC_extremely_fast,
        'TTC_fast': TTC_fast,
        'TTC_normal': TTC_normal,
        'TTC_really fast': TTC_really_fast,
        'TTC_slow': TTC_slow,
        'Quantity_a lot': Quantity_a_lot,
        'Quantity_double': Quantity_double,
        'Quantity_multiple': Quantity_multiple,
        'Quantity_single': Quantity_single,
        'Total_extremely high': Total_extremely_high,
        'Total_high': Total_high,
        'Total_low': Total_low,
        'Total_moderate': Total_moderate,
        'AccountAge_established account': AccountAge_established_account,
        'AccountAge_guest or new': AccountAge_guest_or_new,
        'AccountAge_under 3 year account': AccountAge_under_3_year_account,
        'AccountAge_under year account': AccountAge_under_year_account,
        'Distance_commuter order': Distance_commuter_order,
        'Distance_far order': Distance_far_order,
        'Distance_local order': Distance_local_order,
        'Distance_vacationer order': Distance_vacationer_order
    }]
    return binned_data

# get_location takes an ip and makes an api call to ipapi to get an
# ESTIMATED location of where the zip originated
# In:
#    IPv4 Address
# Out:
#    ip - the ip address that was used for the api call
#    city - the city this ip is believed came from
#    region - for USA this is the state the ip came from
#    country - the country the ip came from
#    postal - the postal code this ip came from
#    lat - the latitude value for this ip
#    long - the longitude value for this ip
def get_location(ip):
    response = requests.get(f'https://ipapi.co/{ip}/json/').json()
    location_data = {
            "ip": ip,
            "city": response.get("city"),
            "region": response.get("region"),
            "country": response.get("country_name"),
            "postal": response.get("postal"),
            "lat": response.get("latitude"),
            "long": response.get("longitude")
            }
    return location_data

# "main" just starts the http request handler.
# All get and post requests will be handled by "MyHandler" class
try:
    verbose = True
    if verbose:
        print_ml_stats()
    httpd = socketserver.TCPServer(("", 8080), MyHandler)
    print("Adjudication server started at localhost:8080" )
    httpd.serve_forever()
except KeyboardInterrupt:
    httpd.server_close()
    print("\nServer stopped")
